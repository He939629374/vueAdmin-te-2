module.exports = {
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'test'
}
