let host = '/api';

export default {
    goodsList: host + '/goods-list',
    goodsDetail: host + '/goods-detail',
    goodsDelete: host + '/goods-delete',
    goodsAdd: host + '/goods-add',
}